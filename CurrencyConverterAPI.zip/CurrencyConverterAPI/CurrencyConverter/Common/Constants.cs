﻿namespace CurrencyConverter.API.Common
{
    public static class Constants
    {
        public const string AuthenticationScheme = "Bearer";
    }
}
