﻿namespace CurrencyConverter.Application.Tests
{
    public class Class1
    {

    }
}
