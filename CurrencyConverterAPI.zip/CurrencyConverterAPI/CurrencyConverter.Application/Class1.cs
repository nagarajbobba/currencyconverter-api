﻿namespace CurrencyConverter.Application
{
    public class Class1
    {

    }
}
