﻿namespace CurrencyConverter.Core.Tests
{
    public class Class1
    {

    }
}
