﻿namespace CurrencyConverter.API.Tests
{
    public class Class1
    {

    }
}
